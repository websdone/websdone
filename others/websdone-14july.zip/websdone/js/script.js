'use strict';
// Create module
var websdoneApp = angular.module('websdoneApp', ['ngRoute', 'ngAnimate']);

// Configure route to pages
websdoneApp.config(function($routeProvider) {
	$routeProvider
	// routes go here
	.when('/', {
		templateUrl : 'pages/home.html',
		controller : 'MainController'
	})
	.when('/about', {
		templateUrl : 'pages/about.html',
		controller : 'AboutController'
	})
	.when('/portfolio', {
		templateUrl : 'pages/portfolio.html',
		controller : 'AboutController'
	})
	.when('/contact', {
		templateUrl : 'pages/contactus.html',
		controller : 'ContactController'
	})
    .otherwise({ redirectTo: '/'});
});

// Create the controller and inject Angular's $scope
websdoneApp.controller('MainController', function($scope) {
	// create message for the page views
	//$scope.message = 'this is the home page';
	// Add class to the page
	$scope.pageClass = 'home';
});

websdoneApp.controller('ContactController', function($scope) {
	// create message for the page views
	//$scope.message = 'this is the home page';
	// Add class to the page
	$scope.pageClass = 'contact';
});

websdoneApp.controller('AboutController', function($scope) {
	// create message for the page views
	//$scope.message = 'this is the about page';
	// Add class to the page
	$scope.pageClass = 'about';
});
// CAROUSEL
websdoneApp.controller('CarouselDemoCtrl', function ($scope) {
  $scope.myInterval = 5000;
  var slides = $scope.slides = [];
  $scope.addSlide = function() {
    var newWidth = 600 + slides.length + 1;
    slides.push({
      image: 'http://placekitten.com/' + newWidth + '/300',
      text: ['More','Extra','Lots of','Surplus'][slides.length % 4] + ' ' +
        ['Cats', 'Kittys', 'Felines', 'Cutes'][slides.length % 4]
    });
  };
  for (var i=0; i<4; i++) {
    $scope.addSlide();
  }
});
